from django.apps import AppConfig


class TaskmanagerConfig(AppConfig):
    name = 'taskmanager'
