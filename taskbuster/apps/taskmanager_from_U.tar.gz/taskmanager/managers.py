# -*- coding: utf-8 -*-
from django.db import models


class EmployeeManager(models.Manager):
    pass


class ProjectManager(models.Manager):
    pass


class DepartmentManager(models.Manager):
    pass


class TagManager(models.Manager):
    pass


class CommentManager(models.Manager):
    pass


class TaskManager(models.Manager):
    pass
